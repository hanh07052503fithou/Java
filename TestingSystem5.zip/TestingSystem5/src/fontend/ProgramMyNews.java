package fontend;

import backend.MyNews;

import java.util.Scanner;

public class ProgramMyNews {
    public static void main(String[] args) {
        Question4();
    }
    private  static   void  Question4(){
        Scanner scanner = new Scanner(System.in);
        MyNews myNews = new MyNews();
        int chon;
        do {
            menu();
             chon= scanner.nextInt();
            switch (chon){
                case 1:myNews.insertNews(); break;
                case 2: myNews.viewlistnew(); break;
                case 3: myNews.averageRate(); break;
                case 4: break;
                default:
                    System.out.println("vui long chon lai");
                    break;
            }

        }while (chon !=4);
    }
    private static void menu(){

        System.out.println("1. insert");
        System.out.println("2. select");
        System.out.println("3. avg");
        System.out.println("4. exit");
        System.out.print("vui lòng chọn: ");
    }
}
