package fontend;

import backend.MyStudents;
import entity.ITStudents;

import java.util.Scanner;

public class ProgramStudents {
    public static void main(String[] args) {
       Question5();
    }
    private  static  void  Question5(){
        Scanner scanner = new Scanner(System.in);
        MyStudents myStudents = new MyStudents();
        int chon;

        do {
            menu();

            chon=scanner.nextInt();

            switch (chon){
                case 1:
                    myStudents.insert();
                    break;
                case 2:
                    myStudents.select();
                    break;
                default: break;
            }

        }while (chon !=4);
    }
    private static void menu(){
        System.out.println("1. nhap");
        System.out.println("2. hien");
        System.out.println("3. tim kiem");
        System.out.println("4. Exit");
        System.out.print("Vui long chon: ");

    }

}
