package entity;

public interface INews {
    void  Display();
    float  Calculate();
}
