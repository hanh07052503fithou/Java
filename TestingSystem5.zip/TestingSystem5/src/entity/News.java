package entity;

public class News  implements INews {
    private int id;
    private String title;
    private String publishDate;
    private  String author;
    private String content;
    private   float averageRate;
    private int[] rate;

    public int[] getRate() {
        return rate;
    }

    public void setRate(int[] rate) {
        this.rate = rate;
    }

   /* public entity.News(int id, String title, String publishDate, String author, String content, float averageRate) {
        this.id = id;
        this.title = title;
        this.publishDate = publishDate;
        this.author = author;
        this.content = content;
        this.averageRate = averageRate;
    }*/

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getPublishDate() {
        return publishDate;
    }

    public String getAuthor() {
        return author;
    }

    public String getContent() {
        return content;
    }

    public float getAverageRate() {
        return averageRate;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setPublishDate(String publishDate) {
        this.publishDate = publishDate;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public void Display() {
        System.out.println("Title: "+this.title+" Author: "+this.author+" PublishDate: "+this.publishDate
        +" Content: "+this.content+" AverageRate: "+this.Calculate());
    }

    @Override
    public float Calculate() {
        averageRate= (float) (rate[0] + rate[1] + rate[2]) / 3;
        return  averageRate;
    }
}
