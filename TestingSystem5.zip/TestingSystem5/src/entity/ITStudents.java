package entity;

public interface ITStudents {
    void  them();
    void hien();
    void timkiem();
}
