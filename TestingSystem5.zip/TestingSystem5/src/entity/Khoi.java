package entity;

public enum Khoi {
    A,B,C
}
