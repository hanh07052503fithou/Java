package entity;

import backend.MyStudents;

import java.util.Scanner;

public class Students implements ITStudents {
    private int    sbd;
    private String hoTen;
    private String diaChi;
    private int    mucUuTien;
    private String  khoi;

    public Students() {
    }

    public Students(int sbd, String hoTen, String diaChi, int mucUuTien, String khoi) {
        this.sbd = sbd;
        this.hoTen = hoTen;
        this.diaChi = diaChi;
        this.mucUuTien = mucUuTien;
        this.khoi = khoi;
    }

    public int getSbd() {
        return sbd;
    }

    public void setSbd(int sbd) {
        this.sbd = sbd;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public int getMucUuTien() {
        return mucUuTien;
    }

    public void setMucUuTien(int mucUuTien) {
        this.mucUuTien = mucUuTien;
    }


    public String getKhoi() {
        return khoi;
    }

    public void setKhoi(String khoi) {
        this.khoi = khoi;
    }

    @Override
    public void them() {

        Scanner scanner=new Scanner(System.in);
        System.out.println("nhap sbd: ");
        setSbd(scanner.nextInt());
        scanner.nextLine();
        System.out.println("nhap ho ten");
        setHoTen(scanner.nextLine());
        System.out.println("Nhap dia chi");
        setDiaChi(scanner.nextLine());
        System.out.println("nhap muc uu tien");
        setMucUuTien(scanner.nextInt());
        scanner.nextLine();
        System.out.println("nhap khoi");
        setKhoi(scanner.nextLine());

    }

    @Override
    public void hien() {
        System.out.println("sbd: " +this.sbd + "  ho ten: " + this.hoTen + " dia chi: " + this.diaChi
                + "  muc uu tien: " + this.mucUuTien + " khoi: " + this.khoi
        );

    }

    @Override
    public void timkiem() {


    }
}
