package backend;

import entity.News;

import java.util.Scanner;

public class MyNews {
    News news =new News();
   // private List<entity.News> newsList;
    public void insertNews(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("nhap id: ");
        news.setId(scanner.nextInt());
        scanner.nextLine();
        System.out.println("nhap author");
        news.setAuthor(scanner.nextLine());
        System.out.println("nhap content");
        news.setContent(scanner.nextLine());
        System.out.println("nhap title");
        news.setTitle(scanner.nextLine());
        System.out.println("nhap Publish");
        news.setPublishDate(scanner.nextLine());
        int[] rate = new int[3];

        for (int i=0; i<3; i++){
            System.out.println("nhap rate thu "+(i+1));
            rate[i]= scanner.nextInt();
        }
        news.setRate(rate);
       // newsList.add(news);
    }
    public  void viewlistnew(){
       news.Display();

    }
    public void averageRate(){
        System.out.println("Avg: "+news.Calculate());
    }

}
