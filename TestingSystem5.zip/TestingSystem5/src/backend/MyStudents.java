package backend;

import entity.Khoi;
import entity.Students;

import java.util.Scanner;

public class MyStudents {
    // Scanner scanner = new Scanner(System.in);
    Students students = new Students();
    public void  insert(){
        students.them();

    }
    public void select(){
        students.hien();
    }
    public void search(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhập sbd cần tìm: ");
        String sbd = scanner.nextLine();
    }
}
